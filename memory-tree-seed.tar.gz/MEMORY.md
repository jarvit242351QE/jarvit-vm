# Memory Summary

## What I Know
- Nothing yet — this is a fresh start!

## Topics
**Personal** → memory/personal/
  - preferences.md: User preferences (empty)
  - about-me.md: Facts about the user (empty)

**Projects** → memory/projects/
  - active.md: Active projects (empty)

**Instructions** → memory/instructions/
  - user-rules.md: User-defined rules and instructions (empty)

**Knowledge** → memory/knowledge/
  - general.md: General knowledge and facts (empty)

**Sessions** → memory/sessions/
  - latest.md: Most recent session log (empty)

## Quick Stats
- Facts stored: 0
- Preferences: 0
- Projects: 0
- Instructions: 0
