# User Rules & Instructions

## Current State (last updated: never)
- No rules set yet

## Related
- See also: memory/personal/preferences.md

## History
- (no changes yet)
