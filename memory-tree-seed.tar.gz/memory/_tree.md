# Memory Tree

## Structure
```
MEMORY.md                         ← Top-level summary (start here)
memory/
├── _tree.md                      ← This file (navigation guide)
├── personal/
│   ├── preferences.md            ← Likes, dislikes, style preferences
│   └── about-me.md               ← Name, location, occupation, facts
├── projects/
│   └── active.md                 ← Current projects and their status
├── instructions/
│   └── user-rules.md             ← Rules the user has set ("always do X")
├── knowledge/
│   └── general.md                ← General facts worth remembering
└── sessions/
    └── latest.md                 ← Most recent session changelog
```

## How to Use
1. Start at MEMORY.md for a quick overview
2. Navigate to the right directory based on topic
3. Read the file before writing — never duplicate
4. When facts change, update Current State and log in History
5. Add Related sections to cross-reference
6. If no file fits, create a new one and update this tree
