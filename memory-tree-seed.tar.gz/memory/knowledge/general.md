# General Knowledge

## Current State (last updated: never)
- No knowledge stored yet

## Related
- See also: memory/projects/active.md

## History
- (no changes yet)
